public class Question1 {
    public static void main(String[] args) {
        // Declare constants
        final int X = 5;
        final int Y = 3;
        
        // Declare variables
        int quotient;
        int remainder;
        
        // Calculate the quotient and remainder
        quotient = X / Y;
        remainder = X % Y;
        
        // Print the result
        System.out.println("Quotient (X / Y): " + quotient + "; Remainder (X % Y): " + remainder);
    }
}
