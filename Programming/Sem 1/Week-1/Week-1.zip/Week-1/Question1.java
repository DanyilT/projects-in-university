public class Question1 {
    public static void main(String[] args) {
        // Declare variables
        String message;

        // Set the value of the message variable
        message = "Java Programming \n\nRocks";

        // Print the message
        System.out.println(message);
    }
}
