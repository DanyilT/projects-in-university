public class Question2 {
    public static void main(String[] args) {
        // Declare variables
        int result1 = 4 * 4;
        int result2 = 3 * 7 + -2 * -8;
        double result3 = (2 * 5 - 6) / (4 * 8 - 30);

        // Print the results and the expressions
        System.out.println("4 × 4 = " + result1);
        System.out.println("3 × 7 + (-2 × -8) = " + result2);
        System.out.println("((2 × 5) - 6) / ((4 × 8) - 30 = " + result3);
    }
}
