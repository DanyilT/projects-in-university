public class Question3 {
    public static void main(String[] args) {
        // Declare variables
        int number1 = 71;
        float number2 = 3.14f;

        // Print the values of the variables
        System.out.println("number1 = " + number1);
        System.out.println("number2 = " + number2);
    }
}
