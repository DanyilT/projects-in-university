public class Question1 {
    public static void main(String[] args) {
        // ASCII values for row 6: 60-69
        for (int i = 60; i <= 69; i++) {
            System.out.print((char) i + " ");
        }
    }
}
