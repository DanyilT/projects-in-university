public class Question1 {
    public static void main(String[] args) {
        // First for-loop: Numbers from 1 to 50
        System.out.println("Numbers from 1 to 50:");
        for (int i = 1; i <= 50; i++) {
            System.out.print(i + " ");
        }

        // Second for-loop: Numbers from 50 to 1
        System.out.println("\nNumbers from 50 to 1:");
        for (int i = 50; i >= 1; i--) {
            System.out.print(i + " ");
        }
    }
}
