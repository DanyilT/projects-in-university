public class Broken {
	public static void main(String args[]) {
		System.out.println("This program contains errors!");
		System.out.println("You must fix all of the errors contained");
		System.out.println("within this program before it will");
		System.out.println("compile and run.");
	}
}