public class Question1 {
    public static void main(String[] args) {
        // Expression I
        if (5 - 1 != 3) {
            System.out.println("5 - 1 != 3 is true");
        } else {
            System.out.println("5 - 1 != 3 is false");
        }

        // Expression II
        if (100 % 50 == 0) {
            System.out.println("100 % 50 == 0 is true");
        } else {
            System.out.println("100 % 50 == 0 is false");
        }

        // Expression III
        if ((21 + 7) / 4 >= 100) {
            System.out.println("(21 + 7) / 4 >= 100 is true");
        } else {
            System.out.println("(21 + 7) / 4 >= 100 is false");
        }
    }
}
