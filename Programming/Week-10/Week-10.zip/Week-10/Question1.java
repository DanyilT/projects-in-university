public class Question1 {
    public static void main(String[] args) {
        menu();
    }

    public static void menu() {
        System.out.println("*********************************");
        System.out.println("**      A M O N G    U S       **");
        System.out.println("*********************************");
        System.out.println("**      1) Take out trash      **");
        System.out.println("**      2) Fix wires           **");
        System.out.println("**      3) Card swipe          **");
        System.out.println("**      4) Vent                **");
        System.out.println("*********************************");
    }
}
