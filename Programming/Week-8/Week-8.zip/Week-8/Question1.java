public class Question1 {
    public static void main(String[] args) {
        // Initialize variables
        int[] numbers = new int[5];
        numbers[0] = 20;
        numbers[1] = 30;
        numbers[2] = 40;
        numbers[3] = 50;
        numbers[4] = 60;

        // Print the array
        System.out.printf("numbers[0] = %d\n", numbers[0]);
        System.out.printf("numbers[1] = %d\n", numbers[1]);
        System.out.printf("numbers[2] = %d\n", numbers[2]);
        System.out.printf("numbers[3] = %d\n", numbers[3]);
        System.out.printf("numbers[4] = %d\n", numbers[4]);
    }
}
