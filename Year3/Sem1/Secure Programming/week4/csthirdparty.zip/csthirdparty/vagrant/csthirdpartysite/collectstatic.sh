. /secrets/config.env
cd /var/www/csthirdpartysite
python3 manage.py collectstatic --no-input

