#service apache2 start
apachectl start

