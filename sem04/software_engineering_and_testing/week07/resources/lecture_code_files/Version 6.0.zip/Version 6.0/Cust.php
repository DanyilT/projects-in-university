<?php

include "User.php";

class Cust extends User {
    public $custName;
    public $custAddress;	
	

    // Contructor - initialises an object - user defined constructor
	// This child constructor will overide the parent constructor
	public function __construct($email, $password, $custName, $custAddress) {		
	   $this->email  = $email;   
       $this->password  = $password;
       $this->custName  = $custName;
	   $this->custAddress = $custAddress;
    }
	
   // Access and Modifier Methods
   public function get_custName() {
    return $this->custName;
   }
   
   
   public function set_custName($custName){
     $this->custName = $custName;
   }
	
	
   public function get_custAddress() {
    return $this->custAddress;
   }
   
   public function set_custAddress($custAddress){
     $this->custAddress = $custAddress;
   }
   
   public function custDetails() {
    echo "</br>I am a customer type of user ";
	echo "</br>My email is " . $this->email;
	echo "</br>My password is " . $this->password;
	echo "</br>My name is " . $this->custName;
	echo "</br>My address is " . $this->custAddress;
  }
	 

 }

  $mycust = new Cust("arnold.hensman@tudublin.ie", "redFruit","Arnold", "TUDublin");  
  $mycust->custDetails();


?>