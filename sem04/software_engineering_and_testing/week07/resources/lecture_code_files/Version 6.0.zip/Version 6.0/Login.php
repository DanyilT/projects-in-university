<?php
 
 include "Cust.php";
 include "Admin.php";
 include "Sale.php";

   

 // Try to call all three methods from outside class
 $customer = new Cust("arnold.hensman@tudublin.ie", "CAR BUYER");  // OK. __construct() is public
 $customer->message(); // OK. message() is public
 $customer->credentialCheck(); // COMPARE IN DB LATER

 $myadmin = new Admin();     // OK. __construct() is public
 $myadmin->message(); // OK. message() is public
 $myadmin->credentialCheck(); // COMPARE IN DB LATER

 


 ?>