<?php
class User {
  public $email;
  public $password;
  
  public function __construct($email, $password) {
    $this->email = $email;
    $this->password = $password;
  }
  
  
  public function credentialCheck() {
    echo "</br>User {$this->email} is logging in with password {$this->password}.";
  }// This function would be used to compare to DB PASSWORD FOR THAT USER
}

 $myuser = new User("arnold.hensman@tudublin.ie", "redFruit");  
 $myuser->credentialCheck();
 
?> 