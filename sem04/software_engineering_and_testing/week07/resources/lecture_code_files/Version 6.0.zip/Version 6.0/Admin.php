<?php

include "User.php";

public class Admin extends User {
  public $adminCode;
  
  
  public function message() {
    echo "</br>I am a Admin type of user ";
  }
  
  
?>