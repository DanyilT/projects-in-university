<?php
class Sale
{
    // property declaration
	public $saleID;
    public $salePrice;
    public $saleCust;     // AGGREGATION
    public $saleSeller;   // AGGREGATION
	
	
    // Contructor
	function __construct($saleID,$salePrice,$saleCust,$saleSeller) {
       $this->saleID  = $saleID;
	   $this->salePrice = $salePrice;
	   $this->saleCust = $saleCust;
	   $this->saleSeller = $saleSeller;
    }
   
    // method declaration
    public function displaySale() {
		echo '<br/> SALE DETAILS : <br/>';
		echo '<br/> _____________  <br/>';
		
		echo 'Sale ID: '      . $this->saleID . '<br/>';
		echo 'Sale Price: '   . $this->salePrice . '<br/>';
		echo 'Sale Customer:' . $this->saleCust->displayCust() . '<br/>';
		echo 'Sale Seller:'   . $this->saleSeller->displaySalesman() . '<br/>';
    }
	
}
?>



