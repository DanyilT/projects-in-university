<?php




// Try to call all three methods from outside class
$strawberry = new Strawberry("Wexford Strawberry", "red");  // OK. __construct() is public
$strawberry->message(); // OK. message() is public

$strawberry->intro(); // ERROR. intro() is protected

?> 