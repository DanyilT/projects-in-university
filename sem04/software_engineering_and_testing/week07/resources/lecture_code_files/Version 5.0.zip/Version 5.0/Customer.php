<?php

// C R U D 
// WITH GENERALISATION - INHERITANCE
class Cust{
    public $custNum;
    public $custName;	
	

    // Contructor - initialises an object - user defined constructor
	function __construct($custNum,$custName) {
       $this->custNum  = $custNum;
	   $this->custName = $custName;
    }
	
	
	
	// Access and Modifier Methods
   public function get_custNum() {
    return $this->custNum;
   }
   public function set_custNum($custNum){
     $this->custNum = $custNum;
   }
	
   public function get_custName() {
    return $this->custName;
   }
   public function set_custName($custName){
     $this->custName = $custName;
   }
   
   
   
	// method declaration
    public function displayCust() {
		echo '<br/>';
		echo 'Cust Num:  '   . $this->custNum  . '<br/>';
		echo 'Cust Name: '   . $this->custName . '<br/>';
    }
}
?>