<?php



// C R U D 
// WITH GENERALISATION - INHERITANCE

class User {
  public $email;
  public $password;
  
  // CONSTRUCTOR CLASS
  public function __construct($email, $password) {
    $this->email = $email;
    $this->password = $password;
  }
  public function credentialCheck() {
    echo "</br>User {$this->email} is logging in with password {$this->password}.";
  }// This function would be used to compare to DB PASSWORD FOR THAT USER
}


class Cust extends User {
  public function message() {
    echo "</br>I am a customer type of user ";
  }
}

class Admin extends User {
  public function message() {
    echo "</br>I am a Admin type of user ";
  }
}

// Try to call all three methods from outside class
$customer = new Cust("arnold.hensman@tudublin.ie", "redFruit");  // OK. __construct() is public
$customer->message(); // OK. message() is public
$customer->credentialCheck(); // COMPARE IN DB LATER

$myadmin = new Admin("registar@tudublin.ie", "bigUniBoss");     // OK. __construct() is public
$myadmin->message(); // OK. message() is public
$myadmin->credentialCheck(); // COMPARE IN DB LATER


?> 