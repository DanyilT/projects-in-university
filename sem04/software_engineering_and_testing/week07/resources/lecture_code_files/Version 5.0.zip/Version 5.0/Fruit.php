
 <?php
 
// C R U D WITH GENERALISATION - INHERITANCE

////////////////////////////////////////////////
//   P A R E N T     C  L  A  S S  - F R U I T
////////////////////////////////////////////////
class Fruit {
  public $name;
  public $color;
  
  public function __construct($name, $color) {
    $this->name = $name;
    $this->color = $color;
  }
  public function intro() {
    echo "<br><br>INTRO METHOD - PARENT CLASS - The fruit is {$this->name} and the color is {$this->color}.";
  }
}


//////////////////////////////////////////////////////////
//   C H I L D     C  L  A  S S  - S T R A W B E R R Y
//////////////////////////////////////////////////////////
class Strawberry extends Fruit {
  public function message() {
    echo "<br><br>MESSAGE METHOD - CHILD CLASS - Am I - A STRAWBERRY -  a fruit or a berry? ";
  }
}

//////////////////////////////////////////////////////////
//   C H I L D     C  L  A  S S  - A P P L E
//////////////////////////////////////////////////////////
class Apple extends Fruit {
  public function message() {
    echo "<br><br>Do I - APPLE -  grow on Trees? ";
  }
}

// Try to call all three methods from outside class
$my_strawberry = new Strawberry("WexfordStrawberry", "red");  // OK. __construct() is public

$my_strawberry->intro(); // ERROR. intro() is protected
$my_strawberry->message(); // OK. message() is public

// Try to call all three methods from outside class
$my_apple = new Apple("Golden Delicious", "green");  // OK. __construct() is public

$my_apple->intro(); // ERROR. intro() is protected
$my_apple->message(); // OK. message() is public



?> 