


public class SubClass extends SuperClass {

	@Override
	public void superMethod(String s) {
		//Subclass overrides the super class method
		//Change made to the superclass method will result in error
		super.superMethod(s);
	}
	
}
