
public class SuperClass {

	public void superMethod(String s) {
		//Blank method to be inherited to demo @Annotation
	}
	
}
