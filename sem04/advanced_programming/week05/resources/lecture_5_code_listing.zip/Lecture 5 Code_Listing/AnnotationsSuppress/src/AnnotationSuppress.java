import javax.swing.JDialog;

public class AnnotationSuppress {
	
	@SuppressWarnings("unused")
	public void methodWithUnusedWarning(String s) {
		String p = s;	
	}
	
	//Note: The above method suppresses the unused variable warning
	//Note: The method below suppresses two warning, one for unused variable
	//and the other for use of a deprecated method 'show()'
	@SuppressWarnings({"unused", "deprecation"})
	public void methodWithWarning() {
		int x = 0;
		JDialog dialog = new JDialog();
		dialog.show();
	}

}
