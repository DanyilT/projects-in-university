import java.text.DateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JLabel;


/**
 * This class run a clock using the Runnable interface approach
 * @author LukeRaeside
 *
 */
public class Clock implements Runnable {

	JLabel display;
	ClockFrame frame;
	boolean paused = false;
	ClockSound sound = new ClockSound();

	public Clock(ClockFrame frame) {
		this.frame = frame;
	}
	/**
	 * Inherited Threaded run method to run the clock (Every second)
	 * Shows paused when the clock is paused
	 */
	@Override
	public void run() {
		while (true) { //operate continuously
			
			//Show time while not paused
			while (!paused) {

				frame.getTimeLabel().setText(getTime());
				frame.getControlLabel().setText("");
				(new ClockSound()).tick();
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
			//Do this while paused
			if (paused) {
				frame.getControlLabel().setText("Paused");
			}
		}
		
	}

	/**
	 * This method returns a string version of the current time
	 * 
	 * @return String The current time in the form of a string
	 */
	protected String getTime() {
		Date date = new Date();
		DateFormat.getDateTimeInstance().format(date);
		//DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(date);
		//DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.MEDIUM).format(date);
		DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG).format(date);

		return date.toString();
	}

	/**
	 * Sets the variable 'paused' to true halting the clock
	 */
	protected void pause() {
		paused = true;
	}

	/**
	 * Sets the variable 'paused' to false resuming the clock
	 */
	protected void resume() {
		paused = false;
	}

}
