import java.io.File;
import java.io.IOException;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

/**
 * 
 */

/**
 * @author LukeRaeside
 *
 */
public class ClockSound {

	/**
	 * @param args
	 */
	File clockTick = new File("Tick.wav");
	Clip theClip;
	
	public ClockSound() {
		try {
			theClip = getSound(clockTick);
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * This method loads a tick sound for the clock 
	 */
	public void tick() {
		if(theClip.isActive()) {
			try {
				theClip = getSound(clockTick);
			} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		theClip.start();
	}
	
	/**
	 * This method will call stop on th click sound
	 */
	public void stopTick() {

		theClip.stop();
	}
	
	/**
	 * Loops the tick sound continuously
	 */
	public void tickLoop() {
		theClip.loop(Clip.LOOP_CONTINUOUSLY);
	}
	
	/**
	 * Return a Clip from the file passed using AudioSystem getAudioInputStream
	 * @param file The file to be loaded
	 * @return The clip that can then be used by the class
	 * @throws UnsupportedAudioFileException Checked exception
	 * @throws IOException Checked exception
	 * @throws LineUnavailableException Checked exception
	 */
	public Clip getSound(File file) throws UnsupportedAudioFileException, IOException, LineUnavailableException {
		// Get file from project directory
		System.out.println(file.toURI().toString());

		// Declare the Audio input class and print out the stream
		try (AudioInputStream audioIn = AudioSystem.getAudioInputStream(file)) {

			// Get a sound clip resource
			theClip = AudioSystem.getClip();

			// Open audio clip and load samples from input stream.
			theClip.open(audioIn);

			return theClip;

		}
	}
	

}
