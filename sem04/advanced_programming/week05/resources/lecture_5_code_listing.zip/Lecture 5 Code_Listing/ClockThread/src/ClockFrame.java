import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * 
 */

/**
 * This class shows an example of a clock that updates every second
 * It uses Threads
 * @author LukeRaeside
 *
 */

@SuppressWarnings("serial")
public class ClockFrame extends JFrame implements ActionListener {
	
	/**
	 * 
	 */
	protected JLabel clockDisplay = new JLabel();
	protected JLabel pausedLabel = new JLabel();
	protected JButton controlButton = new JButton("Pause");
	protected JButton changeColor = new JButton("Color Change");
	protected JPanel buttonPanel = new JPanel();
	protected JPanel displayPanel = new JPanel(new GridLayout(3,1));
	
	Font bigFont = new Font("Sans Serif",Font.BOLD,32);
	Font controlFont = new Font("Arial",Font.BOLD,32);
	Clock clock = new Clock(this);

	public static void main(String[] args) {
		new ClockFrame();

	}
	
	public ClockFrame() {
		clockDisplay.setFont(bigFont);
		clockDisplay.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pausedLabel.setFont(controlFont);
		pausedLabel.setForeground(Color.RED);
		
		displayPanel.add(clockDisplay);
		displayPanel.add(pausedLabel);	
		
		new Thread(clock).start(); //Wrap Runnable in thread before calling start
		//Can be done in two steps
		//Thread clockThread = new Thread(clock);
		//clockThread.start();
		
		this.getContentPane().add(displayPanel);
		
		controlButton.addActionListener(this);
		changeColor.addActionListener(this);
		buttonPanel.add(controlButton);
		buttonPanel.add(changeColor);

		this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		
		setSize(550,200);
		setVisible(true);
		
	}
	
	/**
	 * This method returns the time label for time display
	 * @return JLabel The label reference for the time display
	 */
	public JLabel getTimeLabel() {
		return clockDisplay;
	}
	
	/**
	 * This method return the control label for Pause etc.
	 * @return JLabel The label reference for the control display
	 */
	public JLabel getControlLabel() {
		return pausedLabel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton source = (JButton)e.getSource();
		if(source.getActionCommand().equals("Pause")) {
			controlButton.setActionCommand("Resume");
			controlButton.setText("Resume");
			clock.pause();
		}
		else if(source.getActionCommand().equals("Resume")) {
			controlButton.setActionCommand("Pause");
			controlButton.setText("Pause");
			clock.resume();
		}else if (source==changeColor) {
			Random hue = new Random();
			int r = hue.nextInt(255-0) + 0; //red random
			int g = hue.nextInt(255-0) + 0; //green random
			int b = hue.nextInt(255-0) + 0; //blue random
			clockDisplay.setForeground(new Color(r,g,b));
		}
	}

}
