/**
 * This class defines an enumeration type and uses the enumeration type in the main
 * 
 * @author lukeraeside
 */

import java.util.Iterator;

public class EnumsJava {

	/**
	 * This is an enumeration for the days of the week
	 * 
	 * @author lukeraeside
	 *
	 */
	public static enum DayOfWeek {
		SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY;
		
		public static DayOfWeek printMyFavouriteDay() {
			return DayOfWeek.FRIDAY;
		}
	}
	
	/**
	 * Test the enumeration type for the days of the week
	 * @param args The command line arguments if any
	 * 
	 */
	public static void main(String[] args) {
		
		DayOfWeek currentDay=DayOfWeek.THURSDAY;
		
		//Using if statement to test for Tuesday
		if(currentDay==DayOfWeek.THURSDAY) {
			System.out.println("It's Thursday");
		}
		
		//Using switch to test for all of the days of the week
		switch(currentDay) {
			case SUNDAY: System.out.println("Hi it's Sun");break;
			case MONDAY: System.out.println("Hi it's Mon");break;
			case TUESDAY: System.out.println("Hi it's Tues");break;
			case WEDNESDAY: System.out.println("Hi it's Wed");break;
			case THURSDAY: System.out.println("Hi it's Thurs");break;
			case FRIDAY: System.out.println("Hi it's Fri");break;
			case SATURDAY: System.out.println("Hi it's Sat");break;		
		}
		
		//For each statement to test the values() inherited method from the enumeration class Enum
		for (DayOfWeek day : DayOfWeek.values()) {
		    System.out.println(day);
		}

		//Test the method contained in the enumeration
		System.out.println("My fav day is: " + DayOfWeek.printMyFavouriteDay());
	}

}
