/**
 * This class demonstrates the use of an enumeration with it's own internal data
 * @author lukeraeside
 *
 */
public class EnumWithData {
	
	public enum Pets {
		
		DOG("CHUM"),TORTOISE("GREENS"); //List pets in enumeration
		
		private final String favFood; //represents their fav food
		/**
		 * Constructor for Enumerator
		 * @param favFood The favourite food for the Pet
		 */
		Pets(String favFood) { //What info can be stored in each enum
			this.favFood = favFood;
		}
		
		/**
		 * Returns the favourite food as defined by the enumeration
		 * @return string Represents the favourite food as defined in the enumeration
		 */
		public String getFavFood() {
			return favFood;
		}
	}

	public static void main(String[] args) {
		Pets myFavPet = Pets.TORTOISE;
		System.out.println("My favourite pet is " + myFavPet + " and it needs " + myFavPet.getFavFood());
	}

}
