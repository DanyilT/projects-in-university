
public class TestDeprecated {

	public static void main(String[] args) {
		
		AnnotationsDeprecated.oldMethod();
		
		AnnotationsDeprecated.newMethod();

	}

}
