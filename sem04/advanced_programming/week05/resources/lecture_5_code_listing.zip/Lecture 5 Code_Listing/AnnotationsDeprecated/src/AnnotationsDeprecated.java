
public class AnnotationsDeprecated {

	@Deprecated
	/**
	 * @deprecated please use the new method called newMethod
	 * 
	 */
	public static void oldMethod() {
		
	}
	
	public static void newMethod() {
		
	}
	
}
