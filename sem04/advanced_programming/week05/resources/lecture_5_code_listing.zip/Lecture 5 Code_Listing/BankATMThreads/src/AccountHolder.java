import java.util.Random;

public class AccountHolder extends Thread {

	String name;
	BankAccount account;
	int amount;
	Random rand = new Random();
	Random randTwo = new Random();

	public AccountHolder(String name, BankAccount account) {
		this.name = name;
		this.account = account;
	}

	/**
	 * This is the overridden thread run method
	 * Random amounts between 1 and 10 are withdraw continuously
	 */
	public void run() {
		while (account.balance > 0) {
			int amount = rand.nextInt((10 - 1) + 1) + 1;
			int outOrIn = rand.nextInt((10 - 1) + 1) + 1;
			System.out.println("Balance Before: " + account.getBalance());

			try {
				Thread.sleep(50);
				//account.withdraw(amount); //**Change from sync to non-sync and see if errors occur
				account.withdraw(amount);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		currentThread().setName(name);
		System.out.println("Closing balance " + account.getBalance() + " seen by " + currentThread().getName());
	}

}
