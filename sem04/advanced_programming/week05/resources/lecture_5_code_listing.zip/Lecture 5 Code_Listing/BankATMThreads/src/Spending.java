/**
 * This class is a simulated spending from a shared bank account
 * Set the number sharing the account using NUM_SHARING_ACCOUNT
 * Watch the credit disappear and change from synchronized to not synchronized method in AccountHolder
 * Observe any differences in the way the accounts behave
 * @author LukeRaeside
 *
 */
public class Spending {
	
	BankAccount B1234 = new BankAccount(100);
	final static int NUM_SHARING_ACCOUNT=5;

	public static void main(String[] args) {
		new Spending().doBanking();
	}
	
	/**
	 * This method runs the simulated spending based on numbers sharing
	 * Changing from synchronized withdraw in AccountHolder can change behaviour
	 */
	public void doBanking() {
		for (int i = 0; i < NUM_SHARING_ACCOUNT; i++) {
			new AccountHolder("Person" + i, B1234).start();
		}
	}

}
