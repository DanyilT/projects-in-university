/**
 * This is a shared bank account 
 * The balance is a class field 
 * Credits are integers there are no decimals in this bank
 * @author LukeRaeside
 *
 */
public class BankAccount {
	int balance;
	
	
	public BankAccount(int startBalance) {
		this.balance = startBalance;
	}
	
	/**
	 * This methods withdraws credits from the balance
	 * @param amount The amount to be withdrawn
	 */
	public void withdraw(int amount) {
		if((getBalance()-amount)>=0) {
			balance = getBalance() - amount;
		}

	}
	
	/**
	 * This method withdraws credits but includes synchronized
	 * @param amount The amount to be withdrawn
	 */
	public void withdrawSync(int amount) {
		synchronized (this) {
			if((getBalance()-amount)>=0) {
				balance = getBalance() - amount;
			}
		}
	}
	
	/**
	 * This lodges credits to the balance, uses synchronized
	 * @param amount The amount of credits to lodge
	 */
	public synchronized void lodgeSync(int amount) {
		synchronized (this) {
			balance = getBalance() + amount;
		}
	}
	
	/**
	 * This lodges credit to the balance 
	 * @param amount The amount of credits to lodge
	 */
	public void lodge(int amount) {
		balance = getBalance() + amount;		
	}
	
	/**
	 * Return the balance in credits
	 * @return int The amount of credits in the balance
	 */
	public synchronized int getBalance() {
		return balance;
	}

}
