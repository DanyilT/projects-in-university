/**
 * Class to demonstrate the basic use of varargs using the ... notation
 * @author lukeraeside
 * @version Feb 2017
 *
 */
public class VarArgs {
	
	/**
	 * The main mathod will test the varargs methods in the class (all static)
	 * @param args The params to the main
	 * 
	 */

	public static void main(String[] args) {
	
		System.out.println(addLotsOfNumbers(1,2,3,4,5));
		outputLotsOfStrings("Hello","There", "Hi");
		outputLotsOfDoubles(3.5,4.5,7.8);
		
		String[] abc = {"A", "B", "C"};
		String[] def = {"D","E","F"};
		
		outputLotsOfArrays(abc, def);
		
	}
	/**
	 * This method receives a variable argument of type int and adds them all
	 * @param numList The name of the vararg passed
	 * @return Returns the sum of all the integers passed to the method
	 */
	public static int addLotsOfNumbers(int... numList) {
		
		int total=0;
		
		for (int i = 0; i < numList.length; i++) {
			total+=numList[i];	
		}
		
		return total;
	}
	
	/**
	 * This method takes as input a variable argument of type string and outputs all strings passed
	 * @param strings The vararg for the strings passed
	 */
	public static void outputLotsOfStrings(String... strings) {
		for (int i = 0; i < strings.length; i++) {
			System.out.println(strings[i]);
		}
	}
	
	/**
	 * This method accepts a vararg of double and adds up the total
	 * @param ds Data set of doubles passed
	 * 
	 */
	public static void outputLotsOfDoubles(double... ds) {
		for (int i = 0; i < ds.length; i++) {
			System.out.println(ds[i]);
		}
	}
	
	/**
	 * This method demonstrates the passing of a variable argument array
	 * This is effect creates an array of arrays which is printed out by the method
	 * using a 2D for loop
	 * @param strings The vararg parameter of type String array passed
	 * 
	 */
	public static void outputLotsOfArrays(String[]...strings) {
		for (int i = 0; i < strings.length; i++) {
			for (int j = 0; j < strings[i].length; j++) {
				System.out.println(strings[i][j]);
			}
		}
	}

}
