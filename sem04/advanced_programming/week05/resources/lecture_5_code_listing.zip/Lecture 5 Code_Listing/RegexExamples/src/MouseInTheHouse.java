

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
/**
 * Very simple starting regex search using Pattern and Matcher
 * @author LukeRaeside
 *
 */
public class MouseInTheHouse {
	
	static String s = "Is there a mouse in the house?";
	static String regexString = "mouse";

	public static void main(String[] args) {
		try {
			Pattern pattern = Pattern.compile(regexString,Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(s);
	        int count=0;
	        while(matcher.find()) {
	            count++;
	            System.out.println("Found: " + count + " : "
	                    + matcher.start() + " - " + matcher.end());
	            System.out.println(s.substring(matcher.start(), matcher.end()));
	        }
		}
		catch(PatternSyntaxException e) {
			System.out.println("You're pattern is not correct");
			e.printStackTrace();
		}
	}

}
