

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Very simple starting regex search using Pattern and Matcher
 * 
 * @author LukeRaeside
 *
 */
public class StartsWithEndsWithUsingOR {

	static String s = "Is there a mouse in the house?, I didn't see a mouse";
	static String regexString = "\\b[m]\\w*[e]\\b|\\b[t]\\w*[e]\\b";

	public static void main(String[] args) {
		try {
			Pattern pattern = Pattern.compile(regexString, Pattern.CASE_INSENSITIVE);
			Matcher matcher = pattern.matcher(s);
			//boolean matchFound = matcher.find();
	        int count=0;
	        while(matcher.find()) {
	            count++;
	            System.out.println("Found: " + count + " : at location "
	                    + matcher.start() + " - " + matcher.end());
	            System.out.println("String found: " + s.substring(matcher.start(), matcher.end()));
	        }

		} catch (PatternSyntaxException e) {
			System.out.println("You're pattern is not correct");
			e.printStackTrace();
		}
	}

}
