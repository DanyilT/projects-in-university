import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 * 
 */

/**
 * This class shows an example of a clock that updates every second
 * It this uses a clock *** WITHOUT THREADS ***
 * *** WARNING, BUTTONS NOT WORKING PROPERLY DUE TO NO THREADS
 * *** THE CLOCK STARTING STOPS THE GUI BUILDING PROCESS
 * @author LukeRaeside
 *
 */
@SuppressWarnings("serial")
public class ClockFrame extends JFrame implements ActionListener {
	
	protected JLabel clockDisplay = new JLabel();
	protected JLabel pausedLabel = new JLabel();
	protected JButton controlButton = new JButton("Pause");
	protected JButton changeColor = new JButton("Color Change");

	protected JPanel buttonPanel = new JPanel();
	protected JPanel displayPanel = new JPanel(new GridLayout(2,1));
	
	Font bigFont = new Font("Sans Serif",Font.BOLD,32);
	Font controlFont = new Font("Arial",Font.BOLD,32);
	ClockNoThread clock = new ClockNoThread(this);

	public static void main(String[] args) {
		new ClockFrame();
	}
	
	public ClockFrame() {
		clockDisplay.setFont(bigFont);
		clockDisplay.setBorder(BorderFactory.createLineBorder(Color.BLACK));
		pausedLabel.setFont(controlFont);
		pausedLabel.setForeground(Color.RED);
		
		displayPanel.add(clockDisplay);
		displayPanel.add(pausedLabel);	
		
		clock.setTime(); //*** Not implementing Runnable, blocks GUI
	
		this.getContentPane().add(displayPanel);
				
		controlButton.addActionListener(this);
		changeColor.addActionListener(this);

		buttonPanel.add(controlButton);
		this.getContentPane().add(buttonPanel, BorderLayout.SOUTH);
		buttonPanel.add(changeColor);
		
		setSize(550,200);
		setVisible(true);
	
	}
	
	/**
	 * This method returns the time label for time display
	 * @return JLabel The label reference for the time display
	 */
	public JLabel getTimeLabel() {
		return clockDisplay;
	}
	
	/**
	 * This method return the control label for Pause etc.
	 * @return JLabel The label reference for the control display
	 */
	public JLabel getControlLabel() {
		return pausedLabel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton source = (JButton)e.getSource();
		if(source.getActionCommand().equals("Pause")) {
			controlButton.setActionCommand("Resume");
			controlButton.setText("Resume");
			clock.pause();
		}
		else if(source.getActionCommand().equals("Resume")) {
			controlButton.setActionCommand("Pause");
			controlButton.setText("Pause");
			clock.resume();
		}else if (source==changeColor) {
			Random hue = new Random();
			int r = hue.nextInt(255-0) + 0;
			int g = hue.nextInt(255-0) + 0;
			int b = hue.nextInt(255-0) + 0;
			clockDisplay.setForeground(new Color(r,g,b));
		}
	}

}
