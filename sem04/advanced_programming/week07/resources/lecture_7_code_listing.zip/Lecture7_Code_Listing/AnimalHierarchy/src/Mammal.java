/**
 * 
 */

/**
 * @author LukeRaeside
 *
 */
public abstract class Mammal extends Animal {

	public abstract void move();

	public void lactate() {
	//if female and has young then...
	//produce milk
	}
}
