
public interface CustomLambdaMultiParams {

	int MultiParams(int x, int y);
	
}
