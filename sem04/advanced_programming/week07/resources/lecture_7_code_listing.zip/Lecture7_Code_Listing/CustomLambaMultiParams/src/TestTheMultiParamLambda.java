
public class TestTheMultiParamLambda {

	public static void main(String[] args) {
		
		CustomLambdaMultiParams myLamb = (n,n1)->{ return n * n1; };
		System.out.println(myLamb.MultiParams(6, 6));
	}
	

}
