/**
 * Shows two methods with same signature BUT in different classes
 * @author LukeRaeside
 *
 */
public class ClassOne {

	public int signatureMethod(int x) {
		return 0;
	}
}

class ClassTwo {
	
	public int signatureMethod(int x) {
		return 0;
	}
}