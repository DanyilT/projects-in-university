/**
 * ActionListener is a functional interface and can therefore form a Lambda
 * This shows an actionPerformed call via the Lambda expression
 */
import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;

public class LambdaListener extends JFrame {
	
	JButton button1 = new JButton("Push");

	public static void main(String[] args) {
		new LambdaListener();
	}
	
	public LambdaListener() {
		getContentPane().add(button1, BorderLayout.NORTH);
		setSize(50,50);
		setVisible(true);
		//Add listener using Lambda expression
		button1.addActionListener(e->{System.out.println("Button pushed");});
	}

}
