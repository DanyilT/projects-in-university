/**
 * 
 */

/**
 * @author LukeRaeside
 *
 */
import java.util.Vector;

public class ClassList {

	private Vector<Student> classList; 

	public ClassList() {
		classList = new Vector<Student>();
	}

	public void addToClass(Student student) {
		classList.add(student);
	}

	public Vector<Student> getClassList() {
		return classList;
	}
}
