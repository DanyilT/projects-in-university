/**
 * The two methods have different signatures
 * The parameters are in different order
 * @author LukeRaeside
 *
 */
public class DifferentSignature {

	public int signatureMethod(int p, double x) {
		return 0;	
	}
	
	public double signatureMethod(double x, int p) {
		return 0;
	}
}
