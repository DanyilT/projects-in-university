/**
 * Deliberate error here!: The compiler will not allow this class to compile
 * The method signatures are the same within the same scope
 * 
 * @author LukeRaeside
 *
 */
public class SameSignature {

	public int signatureMethod(int p, double x) {
		return 0;	
	}
	
	public double signatureMethod(int x, double p) {
		return 0;
	}
}
