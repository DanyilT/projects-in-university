/**
 * An interface, Phones must have a number and make and receive calls
 * Implementations are left to the implementers
 * Variables by default public static final even if not written 
 * You can have default implementation
 * You can have private implementations
 * You can have static implementations
 * You can have private static implementations
 * Interfaces can extends each other 
 * Interface can extend as many interfaces as they like (unlike class)
 * @author LukeRaeside
 *
 */
public interface Phone {

	long number=387777777; //public static final whether declared or not
	
	/**
	 * If this interface is implemented then the implementer is responsible
	 * for the implementations details of how this works, i.e., if you makeCalls
	 * and receive calls you are a phone, what was you do it is you business!
	 * Note: these are public abstract methods whether stated or not
	 */
	public void makeCall();
	public void receiveCall();
	
	/**
	 * This is an example of a default behaviour
	 * Default methods can be overidden in the subclasses
	 */
	default void endCall() {
		//Cut the call
	}
	
	/**
	 * This is a private method allowed since Java 9
	 */
	private void interfaceMethod() {
		//This is allowed since Java 9
	}
	
	/**
	 * Static method allowed since Java 9
	 */
	public static void staticAllowed() {
		//This is allowed since Java 9
	}
	
	/**
	 * Static private methods since Java 9
	 */
	private static void privateStatic() {
		//Private static method 
	}
}

