/**
 * Shows example implementation of Phone interface
 * @author LukeRaeside
 *
 */
public class HousePhone implements Phone {
	
	//If the class wants it's own number, override the default
	//static long number = 5555555;

	@Override
	public void makeCall() {
		// TODO Auto-generated method stub
		//Lift receiver from charger or wall and dial number
		//Wait for ring

	}

	@Override
	public void receiveCall() {
		// TODO Auto-generated method stub
		//Listen for ringing
		//Life receiver from charger or wall or push button to talk

	}
	
	@Override
	public void endCall() {
		// This rejects the default behaviour in the subclass
	}
	
	public static void main(String[] args) {
		System.out.println("My number is " + number + " unless I override the default");
		
	}

}
