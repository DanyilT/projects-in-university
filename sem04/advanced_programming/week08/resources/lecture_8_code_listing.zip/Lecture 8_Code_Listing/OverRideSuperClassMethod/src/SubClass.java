/**
 * This subclass is NOT overriding the super class
 * This is because the signatures DO NOT MATCH
 * The signatures of the methods MUST match for Override
 * @Override annotation won't work
 * @author LukeRaeside
 *
 */
public class SubClass extends SuperClass {
	
	public void signatureMethod(int p, double x) {
		System.out.println("Child " + this.getClass().getName());	
	}
}
