
public class SuperClass {
	public void signatureMethod(double x) {
		System.out.println("Parent " + this.getClass().getName());	
	}
}
