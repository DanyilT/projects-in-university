/**
 * This subclass IS overriding the super class
 * This is because the signatures MATCH
 * The signatures of the methods MUST match for Override
 * @Override annotation will work in this example
 * @author LukeRaeside
 *
 */
public class SubClassOveride extends SuperClass{
	
	@Override
	public void signatureMethod(double x) {
		// TODO Auto-generated method stub
		super.signatureMethod(x);
	}

}
