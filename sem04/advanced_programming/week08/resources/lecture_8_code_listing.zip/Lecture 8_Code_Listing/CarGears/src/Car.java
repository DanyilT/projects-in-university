
public abstract class Car {

	protected int numberOfGears;

	public abstract String getGearChangeInstructions();

	public int getNumberOfGears() {
		return numberOfGears;
	}
}
