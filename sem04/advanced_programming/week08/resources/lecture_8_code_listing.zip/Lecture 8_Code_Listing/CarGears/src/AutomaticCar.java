
public class AutomaticCar extends Car {
	public AutomaticCar(int numberOfGears) {
		this.numberOfGears = numberOfGears;
	}

	public String getGearChangeInstructions() {

		String desc = "Gear change for " + this.getClass().getName();
		String step1 = "Set lever to selected gear";
		String step2 = "Car will automatically cycle between gears";

		return desc + "\n" + step1 + "\n" + step2;
	}

}
