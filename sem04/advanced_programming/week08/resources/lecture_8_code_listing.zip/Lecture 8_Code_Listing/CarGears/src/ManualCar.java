
public class ManualCar extends Car {
	public ManualCar(int numberOfGears) {
		this.numberOfGears = numberOfGears;
	}

	public String getGearChangeInstructions() {

		String desc = "Gear change for " + this.getClass().getName();
		String step1 = "Push clutch";
		String step2 = "Select new gear";
		String step3 = "Release clutch";

		return desc + "\n" + step1 + "\n" + step2 + "\n" + step3;
	}

}
