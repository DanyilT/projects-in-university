import java.util.Vector;

public class Garage {

	public static void main(String[] args) {
		
		Car chitty1 = new AutomaticCar(6);
		Car chitty2 = new ManualCar(5);

		Vector<Car> listOfCars = new Vector<Car>();
		
		listOfCars.addElement(chitty1);
		listOfCars.addElement(chitty2);
		
		
		for (int i = 0; i < listOfCars.size(); i++) {
			System.out.println(listOfCars.elementAt(i).getGearChangeInstructions()+"\n");
		}
	}

}
