/**
 * This class can be used to show the info stored in objects while debugging
 * The loop can also be used to show conditional breakpoints, e.g., set fishCount>1 can be a condition for the breakpoint
 */
import java.util.ArrayList;

public class ObjectDebug {
	
	public static void main(String[] args) {
		Fish silverFish = new Fish("Sliver","Koi");
		Fish blackFish = new Fish("Charcoal","Koi");
		Fish yellowFish = new Fish("Sulphur","Koi");
		
		ArrayList<Fish> myFish = new ArrayList<>();
		
		myFish.add(silverFish);
		myFish.add(blackFish);
		myFish.add(yellowFish);
		
		int fishCount = 0; //set a conditional breakpoint here, e.g., fishCount>1
		//If 'resume' is selected it jumps to the conditional breakpoint only
		for (Fish fish : myFish) {
			System.out.println(fish.getName() + fishCount++);
		}
	}

}
