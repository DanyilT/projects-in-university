/**
 * A program that gives 100,000 welcomes..."Céad míle fáilte"
 * @author LukeRaeside
 *
 */
public class CeadMileFailte {

	public static void main(String[] args) {
		
		for (int i = 0; i < 100000; i++) {
			System.out.println("Fáilte! ");
			System.out.println(i);
			System.out.println(" times.");
		}

	}

}
