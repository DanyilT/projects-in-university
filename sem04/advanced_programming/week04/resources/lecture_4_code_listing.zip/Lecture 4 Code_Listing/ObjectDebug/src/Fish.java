
public class Fish {
	
	String name;
	String species;
	
	public Fish(String name, String species) {
		super();
		this.name = name;
		this.species = species;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecies() {
		return species;
	}
	public void setSpecies(String species) {
		this.species = species;
	}
	
}
