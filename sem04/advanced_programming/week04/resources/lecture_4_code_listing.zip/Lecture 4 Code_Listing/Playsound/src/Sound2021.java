import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;

/**
 * 
 */

/**
 * @author lukeraeside
 *
 */
public class Sound2021 extends JFrame {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		new Sound2021();

	}

	public Sound2021() {
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Test Sound Clip");
		this.setSize(300, 200);
		this.setVisible(true);

		try {
            File file = new File("1-welcome.wav");
            file.toURI();
            System.out.println(file.toURI().toString()); //Get file from project directory
            assert file != null;
            AudioInputStream audioIn = AudioSystem.getAudioInputStream(file.toURI().toURL());
            // Get a sound clip resource.
            Clip clip = AudioSystem.getClip();
            // Open audio clip and load samples from the audio input stream.
            clip.open(audioIn);
            clip.start();
            //clip.loop(Clip.LOOP_CONTINUOUSLY); //To loop
            //clip.loop(10);
            try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            clip.stop(); //start causes playback to continue from the position where playback was last stopped
            try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}           
            clip.start();
		} catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
			e.printStackTrace();
		}
	}

}
