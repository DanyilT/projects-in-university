import java.util.Locale;
import java.util.ResourceBundle;

public class SimplestPropertyTranslationEclipse {

	static Locale loc = new Locale("ga","IE");
	static ResourceBundle transBundle = ResourceBundle.getBundle("trans.trans",loc);

	public static void main(String[] args) {
		
		System.out.println(transBundle.getString("tag1"));
		
		
	}
	
	
}
