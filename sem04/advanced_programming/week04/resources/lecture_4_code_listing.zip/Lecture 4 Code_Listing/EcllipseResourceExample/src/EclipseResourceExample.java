import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.JButton;
import javax.swing.JFrame;

/**
 *  This class will demonstrate how to import the property files in Eclipse straight from the project directory
 *  This is more straight forward a way to import as the files will not need to be in the 'bin'
 *  Put the _de properties file in the project directory
 */

/**
 * @author LukeRaeside
 *
 */
public class EclipseResourceExample extends JFrame {
	
	JButton button1;
	Locale loc = new Locale("de","DE");
	ResourceBundle transBundle = ResourceBundle.getBundle("translate",loc);

	public static void main(String[] args) {
		new EclipseResourceExample();
	}

	public EclipseResourceExample() {
		button1 = new JButton(transBundle.getString("tag1"));
		getContentPane().add(button1);
		setSize(200,200);
		setVisible(true);
	}

}

