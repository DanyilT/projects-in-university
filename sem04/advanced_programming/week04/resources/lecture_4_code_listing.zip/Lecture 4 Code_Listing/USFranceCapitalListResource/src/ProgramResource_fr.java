import java.util.ListResourceBundle;

import javax.swing.ImageIcon;

/**
 * 
 */

/**
 * This is the US ListResource class
 * @author LukeRaeside
 *
 */
public class ProgramResource_fr extends ListResourceBundle {

  private static final Object[][] contents = { {"imageKey",new ImageIcon("images/Eiffel.jpg")} , {"titleKey","Le Capital"}};

  public Object[][] getContents() { return contents; }
}
