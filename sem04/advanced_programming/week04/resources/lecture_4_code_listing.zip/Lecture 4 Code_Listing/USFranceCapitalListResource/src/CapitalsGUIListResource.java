import java.awt.BorderLayout;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 * 
 */

/**
 * This class uses LIST resource bundles to show an image based on the locale
 * When set to France (FR) it shows Eiffel Tower, set to US shows White House
 * 
 * @author LukeRaeside
 * 
 */
public class CapitalsGUIListResource extends JFrame implements ListSelectionListener {
	
	//Selection for france or US
	String[] capitals = {"FR","US"};
	
	//Set up locales
	Locale US = new Locale("US");
	Locale FR = new Locale("FR");
	Locale currentLocale;
	
	//Set up list for switching
	JList<String> list = new JList<String>(capitals);
	JLabel displayLabel = new JLabel();

	
	public CapitalsGUIListResource() {
		getContentPane().add(list,BorderLayout.NORTH);
		getContentPane().add(displayLabel,BorderLayout.CENTER);	
		list.addListSelectionListener(this);
		setSize(300,500);
		setVisible(true);
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new CapitalsGUIListResource();
	}
	
	@Override
	public void valueChanged(ListSelectionEvent e) {
		if(list.getSelectedValue().equals("US")) {
			currentLocale = US;
		}
		else {
			currentLocale = FR;
		}
		//Create resource based on the locale selected
		ResourceBundle res; 
		res = ResourceBundle.getBundle("ProgramResource",currentLocale);
		//Get the image for the current locale from the LIST ResourceBundle
		ImageIcon image = (ImageIcon)res.getObject("imageKey");
		displayLabel.setIcon(image);
		//Get the title from the resource (French or US)
		setTitle(res.getString("titleKey"));

	}

}
