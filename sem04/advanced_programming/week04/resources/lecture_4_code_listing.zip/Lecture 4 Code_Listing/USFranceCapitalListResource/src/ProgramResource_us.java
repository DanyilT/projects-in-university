import java.util.ListResourceBundle;

import javax.swing.ImageIcon;

/**
 * This is the US ListResource class
 * Returns an image for 'imageKey' [US]
 * Returns a string for the 'titleKey' [English]
 * @author LukeRaeside
 *
 */
public class ProgramResource_us extends ListResourceBundle {

  private static final Object[][] contents = { {"imageKey",new ImageIcon("images/Whitehouse.jpg")} , {"titleKey","The Capital"}};

  public Object[][] getContents() { return contents; }
}
