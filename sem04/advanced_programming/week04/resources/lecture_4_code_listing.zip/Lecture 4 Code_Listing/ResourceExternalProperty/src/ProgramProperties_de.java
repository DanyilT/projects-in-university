/**
 * This class directs the translation to the external property file for German (_de)
 * It will try to find the property file in the 'bin' directory (or where .class files are)
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.PropertyResourceBundle;


public class ProgramProperties_de extends PropertyResourceBundle {

  public ProgramProperties_de() throws IOException {
   //This piece of could looks for the property file in the bin directory (or where .class files found)
   super(ProgramProperties_de.class.getResourceAsStream("ProgramProperties_de.txt"));
  }
}

