/**
 * This is a class that can be used to demo basic debugging
 * Uses primitive types and simple method to step in to
 * @author LukeRaeside
 *
 */
public class BasicDebug {

	public static void main(String[] args) {
		
		int firstNum = 8;
		int secondNum = 9;
		int total;
		
		total = stepInHere() + firstNum + secondNum;
		
		System.out.println(total);

	}
	
	private static int stepInHere() {
		int localVariable = 10;
		return localVariable;
	}

}
