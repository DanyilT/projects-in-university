/**
 * 
 * @author lukeraeside
 * 
 * A class to show an inner class and how the classes can reference each other
 *
 */

public class OuterClass {
	int outerInt;

	public static void main(String[] args) {
		new OuterClass().new Inner().accessOuter();
		//This is an outer class and creates and references the inner
	}

	class Inner {
		//This is an inner class and references the outer class
		public void accessOuter() {
			System.out.println("Value is " + OuterClass.this.outerInt);
			OuterClass.this.outerInt=1;
			System.out.println("Value is " + OuterClass.this.outerInt);
		}
	}
}