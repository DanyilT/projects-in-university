/**
 * A class to demonstrate the use of a generic method
 * @author lukeraeside
 *
 */
public class GenMethods {

	public static void main(String[] args) {
		
		
		String s = "Hello";
		genMethodOutputName(s);

	}
	
	/**
	 * Defines a type generic <T> within the method and return the fully qualified name of the class
	 * @param intT The type passed
	 */
	public static <T> void genMethodOutputName(T intT) {
		T t=intT;
		System.out.println(t.getClass().getName());
	}

}

