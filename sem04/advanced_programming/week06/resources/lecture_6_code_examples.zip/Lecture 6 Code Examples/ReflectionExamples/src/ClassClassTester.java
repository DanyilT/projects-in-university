
/**
 * @author lukeraeside
 * 
 * This class tests some of the reflection class methods
 */

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class ClassClassTester {

	public String string1;// field

	// Just some method to use for test purposes
	public int multi(String test) {
		System.out.println("Hello, you called " + this.getClass().getName());
		return 0;
	}

	// Just some method to use for test purposes
	public void maxi() {
		System.out.println("Hello");

	}

	// Just some method to use for test purposes
	public void maxi2() {
		System.out.println("Hello");

	}

	public static void main(String[] args) {

		ClassClassTester tester = null;

		try {
			// newInstance method called directly is now deprecated!
			// tester = (ClassClassTester)Class.forName("ClassClassTester").newInstance();

			tester = (ClassClassTester) Class.forName("ClassClassTester").getDeclaredConstructor().newInstance();
			// Just get the class
			Class testClass = Class.forName("ClassClassTester");

			System.out.println("Name of class loaded: " + testClass.getName());

		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
				| NoSuchMethodException | SecurityException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// Calling a method on the tester object having never used 'new' to create it
		tester.multi("test");// call to the method multi

		// Use instance to get all the public methods in the ClassClassTester class
		Method[] methods = tester.getClass().getDeclaredMethods();

		// Use class reference to use reflection to find names of methods
		for (int i = 0; i < methods.length; i++) {
			System.out.println("Method " + i + " is: " + methods[i].getName());
			
			//Get the parameters
			Parameter[] params = methods[i].getParameters();
			for (int j = 0; j < params.length; j++) {
				System.out.println("Param: " + params[j].getName() + " type: " + params[j].getType().toString());
			}
		}

	}

}