import javax.swing.JButton;
import javax.swing.JFrame;

public class LambdaActionButton extends JFrame {

	JButton button1 = new JButton("Test Lambda");

	public static void main(String[] args) {
		new LambdaActionButton();

	}

	public LambdaActionButton() {

		button1.addActionListener(e -> {
			System.out.println("Action the Lambda way!");
		});

		getContentPane().add(button1);

		setSize(200, 200);
		setVisible(true);
	}

}
