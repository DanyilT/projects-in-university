//A functional interface

public interface TestLambdaIFace {

	int testMethod(int x);

}
