
public interface LambdaMultiParam {
	
	int processNums(int x, int y);

}
