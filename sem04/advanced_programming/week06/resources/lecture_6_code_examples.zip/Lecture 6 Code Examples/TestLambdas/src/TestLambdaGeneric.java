
public interface TestLambdaGeneric<T> {
	
	T testGen(T t);

}
