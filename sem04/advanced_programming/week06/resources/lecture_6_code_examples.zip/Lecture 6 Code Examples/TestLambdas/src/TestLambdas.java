
public class TestLambdas {

	public static void main(String[] args) {
		TestLambdaIFace f = (ans)->(ans + 2);
		
		TestLambdaIFace g = (int ans)->(ans + 2);
		
		
		System.out.println(""+f.testMethod(3)); //Adds two to number
		
		//Black lambda, execute the lambda in a block
		
		int[] arr = {1,2,3,4,5,6,7};
		
		TestLambdaIFace blk = (int x) -> {
			
			for (int i = 0; i < arr.length; i++) {
				x += arr[i];
			}
			
			return x;
		};
		
		System.out.println(blk.testMethod(5));
		
		//Test the generic interface using lambda
		
		TestLambdaGeneric<String> t = (p) -> (p=p+"x");
		
		System.out.println(t.testGen("Hi"));
		
		TestLambdaGeneric<Integer> i = (o) -> (o=o+3);
		
		System.out.println(i.testGen(4));
		
		//Pass Lambda as parameter to a method
		
		System.out.println(Math.max(f.testMethod(3),blk.testMethod(5)));

		//More than one parameter
		
		LambdaMultiParam multi = (n,p) -> n = p + n;
		
		System.out.println(multi.processNums(9,8));
		
		
	}

}
