
/**
 * This class tried to find a file as if in a Jar file
 * If that fails it tries to find the file in the project
 * So it works to find the image in jars and in project directories
 * 
 */

import java.awt.HeadlessException;
import java.awt.Image;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class GetImageInJarAndProject extends JFrame {

	Image resourceImage;
	Icon resourceIcon;
	JPanel imagePanel = new JPanel();
	JLabel imageLabel = new JLabel();
	String imageName = "bug1.gif";

	public void displayImage(String image) {
		URL imgURL = null;

		try { //Try to access using getResource as if in a Jar file
			imgURL = GetImageInJarAndProject.class.getResource("/images/" + image);

			JOptionPane.showMessageDialog(this,"File found in jar file at " + imgURL.toURI().toString());

		} catch (Exception e) { //Failed to find image so image not a Jar: get from project dir
			File fileImage = new File("images/bug1.gif");
			System.out.println("In a project");
			try {
				imgURL = fileImage.toURI().toURL();
				JOptionPane.showMessageDialog(this,"File found in project at " + imgURL.toURI().toString());
			} catch (MalformedURLException | HeadlessException | URISyntaxException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		if(imgURL==null) {
			JOptionPane.showMessageDialog(this,"File not found");
		} else {
			resourceIcon = new ImageIcon(imgURL);
			imageLabel.setIcon(resourceIcon);

			imagePanel.add(imageLabel);
			getContentPane().add(imagePanel);
		}


	}

	public GetImageInJarAndProject() {

		displayImage(imageName);

		setSize(300, 300);
		setVisible(true);
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new GetImageInJarAndProject();
	}
}
