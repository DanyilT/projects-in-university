/**
 * Define a generic class to set and get the type of the variable passed to the generic class
 * @author lukeraeside
 *
 * @param <T> The type parameter passed to the generic class
 */
public class MyGenericClass<T> {

	private T type;
	
	/**
	 * Set the type
	 * @param type The type passed to the class T
	 */
	public void setType(T type) {
		this.type=type;
	}
	
	/**
	 * Get the type set in the generic
	 */
	public T getType() {
		return this.type;
	}
	
}
