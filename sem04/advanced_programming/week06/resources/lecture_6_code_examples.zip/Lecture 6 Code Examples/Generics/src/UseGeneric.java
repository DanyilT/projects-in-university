/**
 * This is a class the demonstrate the use of a generic class called MyGenericClass
 * @author lukeraeside
 *
 */
public class UseGeneric {

	public static void main(String[] args) {
		MyGenericClass<Integer> test = new MyGenericClass<>();
		//If less than Java 1.7 use new MyGenericClass<Integer>();
		test.setType(1);
		System.out.println(test.getType());
		
		MyGenericClass<Double> test1 = new MyGenericClass<Double>();
		test1.setType(1.0);
		System.out.println(test1.getType());

		MyGenericClass<String> test2 = new MyGenericClass<>(); //Uses diamond only for 1.7+
		test2.setType("Yes");
		System.out.println(test2.getType());
		
		
	}

}
