/**
 * A tester class to test the Generic ClassReporter
 * @author lukeraeside
 */
import java.util.Vector;

import javax.swing.JList;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ClassReporterTest {

	public static void main(String[] args) {
		
		//Create the generic class passing the type parameter <JTextField>
		ClassReporter testClass = new ClassReporter();
		System.out.println(testClass.getClassName(new JList()));

	}

}
