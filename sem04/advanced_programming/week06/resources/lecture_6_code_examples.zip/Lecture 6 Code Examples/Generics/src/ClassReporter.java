/**
 * This class reports things about any other class, e.g., the name
 * 
 * @author lukeraeside
 *
 */
public class ClassReporter <T> {
	
	private T type;
	
	/**
	 * Get the name of the class passed to the generic class
	 * 
	 * @param type The type of the class passed
	 * @return string The string representation of class fully qualified  name
	 */
	public String getClassName(T type) {

		return type.getClass().getName();
		
	}
	
	/**
	 * Get the package name the class is in
	 * 
	 * @param type The type of the class passed
	 * @return string The string representation of the package the class is in
	 */
	public String getClassPackage(T type) {
		return type.getClass().getPackage().getName();
	}
	
}
