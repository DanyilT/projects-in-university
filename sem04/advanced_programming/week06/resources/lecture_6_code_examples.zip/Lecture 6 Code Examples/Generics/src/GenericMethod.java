/**
 * A class to demonstrate generic method
 * 
 * @author lukeraeside
 * 
 */

import java.util.Vector;

public class GenericMethod {

	public static void main(String[] args) {
		
		System.out.println(getClassName(new Vector()));

	}
	
	/**
	 * This a generic method to return the fully qualified name of the generic class
	 *
	 * @param inClass The generic type passed as parameter
	 * @return string Return the fully qualified name of the class
	 */
	public static <T> String getClassName(T inClass) {
		return inClass.getClass().getName();
	}

}
