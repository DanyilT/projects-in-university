/**
 * @author lukeraeside
 * 
 * A class to demonstrate the creation of an anonymous inner class
 * The comments show the location of the anonymous class
 */
import java.awt.event.*;
import java.awt.FlowLayout;
import javax.swing.JFrame;
import javax.swing.JButton;


public class AnonymousInnerClass extends JFrame {
	
	public static void main(String[] args) {
		JButton button1;
		AnonymousInnerClass GUI = new AnonymousInnerClass();
		button1 = new JButton("Say Hello");
		GUI.getContentPane().setLayout(new FlowLayout());
		GUI.getContentPane().add(button1);
		//Anonymous class begins
		button1.addActionListener(new ActionListener() {
		  public void actionPerformed(ActionEvent e) {
			 System.out.println("Hello");
		  }
	    });
		//Anonymous class ends
		GUI.setSize(300,300);
		GUI.setVisible(true);
	}
}
